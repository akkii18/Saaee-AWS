const express = require('express');
const session = require('express-session');
const https = require('https')
const request = require('request')

const app = express();
app.use(session({secret : 'secret-key',
                        resave : false,
                        saveUninitialized: false}));

app.use(express.json());
app.use(express.urlencoded({extended : false}));

app.set('view engine', 'ejs');
app.use(express.static( "assets" ) );

const get_data_db = (table_name, method, username=null, where_entities=null) => {
  if(where_entities == null){
    where_entities = ""
  }
  
  var request = require('sync-request');
  var res = request('POST', 'https://o5zcv21n1k.execute-api.us-east-1.amazonaws.com/dev/' + method, {
    json: {
      "operation": "get",
      "table": table_name,
      "where_entities": where_entities,
      "values": {
        "username": username
      }
    }
  });
  var data = JSON.parse(res.getBody('utf8'));
  return data
}

const insert_data_db = (table_name, method, values=null) => {
  if(where_entities == null){
    where_entities = ""
  }
  
  var request = require('sync-request');
  var res = request('POST', 'https://o5zcv21n1k.execute-api.us-east-1.amazonaws.com/dev/' + method, {
    json: {
      "operation": "insert",
      "table": table_name,
      "where_entities": "",
      "values": values
    }
  });
  var data = JSON.parse(res.getBody('utf8'));
  return data
}

app.get('', (req, res) => {
    if(req.session.username == null){
      res.render('index');
    }
    else{
      return res.redirect('/main')
    }
    
    
})

app.get('/login_success/:usr/:pwd', (req, res) => {
  req.session.username = req.params.usr;
  req.session.password = req.params.pwd;
  return res.redirect('/main')
})

app.get('/login_questionnare/:usr/:pwd', (req, res) => {
  req.session.username = req.params.usr;
  req.session.password = req.params.pwd;
  return res.redirect('/login_questionnare')
})

app.get('/login_questionnare', (req, res) => {
  if(req.session.username == null){
    res.render('index');
  }
  res.render('questionnaire', {username: req.session.username, password: req.session.password});
})

app.get('/userdetails', (req, res) => {
  if(req.session.username == null){
    res.render('index');
  }
  data = get_data_db("UserDetails", 'insert-or-update', username=req.session.username)
  res.render('userdetails', {username : req.session.username, userdata: data});
})

app.get('/get-post-data/:postId', (req, res) => {
  if(req.session.username == null){
    res.render('index');
  }
  var post_id = req.params.postId;
  post_data = get_data_db("posts", 'insert-db', username=null, where_entities={"id": post_id})
  comment_data = get_data_db("comments", 'insert-db', username=null, where_entities={"post_id": post_id})
  res.render('post', {postData: post_data, commentsData: comment_data, username : req.session.username})
})

app.get('/main', (req, res) => {
  if(req.session.username == null){
    res.render('index');
  }
  data = get_data_db("posts", 'insert-db' )
  res.render('main', {username: req.session.username, posts: data });
})

app.get('/get-user-details/:usr', (req, res) => {
  if(req.session.username == null){
    res.render('index');
  }
  data = get_data_db("UserDetails", 'insert-or-update', username=req.params.usr)
  res.render('otherUser', {username : req.session.username, userdata: data});
})

app.get('/chat-with/:usr', (req, res) => {
  if(req.session.username == null){
    res.render('index');
  }
  other_user = req.params.usr
  data = get_data_db("conversations", 'insert-db', username=null, where_entities={"user1": req.session.username, "user2": other_user})
  if( data.length == 0 ){
    data = get_data_db("conversations", 'insert-db', username=null, where_entities={"user2": req.session.username, "user1": other_user})
  }
  if( data.length != 0 ){
    chat_data = get_data_db("messages", 'insert-db', username=null, where_entities={"conv_id": data[0]['conv_id']})
    //console.log(chat_data)
    res.render('chat', {messages: chat_data, username: req.session.username, conv_id: data[0]['conv_id'], other_user: other_user})
  }
  else{
    adding_data = insert_data_db("conversations", 'insert-db', values={"sender": req.session.username, "receiver": other_user})
    data = get_data_db("conversations", 'insert-db', username=null, where_entities={"user1": req.session.username, "user2": other_user})
    chat_data = get_data_db("messages", 'insert-db', username=null, where_entities={"conv_id": data[0]['conv_id']})
    //console.log(chat_data)
    res.render('chat', {messages: chat_data, username: req.session.username, conv_id: data[0]['conv_id'], other_user: other_user})
  }
  
})

app.get('/signup', (req, res) => {
  res.render('signup');
})

app.get('/logout', (req, res) => {
  req.session.username = null
  return res.redirect('/');
})

app.get('/userposts', (req, res) => {
  if(req.session.username == null){
    res.render('index');
  }
  data = get_data_db("posts", 'insert-db', username=null,where_entities={"username": req.session.username})
  res.render('userposts', {username : req.session.username, posts: data});
})

app.get('/changepassword',(req,res) =>{
  if(req.session.username == null){
    res.render('index');
  }
  data = get_data_db("UserDetails", 'insert-or-update', username=req.session.username)
  res.render('changepassword', {userdata: data});
})

app.get('/editdetails',(req,res) =>{
  if(req.session.username == null){
    res.render('index');
  }
  res.render('editdetails', {username: req.session.username, password: req.session.password});
})

const PORT = process.env.PORT || 3000; 
app.listen(PORT ,() => console.log(`Server started on port ${PORT}`))
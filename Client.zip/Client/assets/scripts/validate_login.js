//checking if the page is loaded
$(document).ready(function(){
  
    //function to handle button click event
    //accessing the button using its 'id'
    $("#login").click(function(){

      if($("#username").val() != '' && $("#password").val() != ''){
      //creating the payload for adding into UserDetails table
      payload = {
      "table": "UserDetails",
      "values": {
        "username": $("#username").val(),
        "password": $("#password").val()
      }
    }
  
    //sending async request to the api gateway with the payload
    $.ajax({
      //method
      method: 'POST',
      //link to our API
      url: 'https://o5zcv21n1k.execute-api.us-east-1.amazonaws.com/dev/validate-login',
      //type of data we are sending
      dataType: 'json',
      contentType: 'application/json',
      //converting JS object to JSON string - as our lambda need json strings
      data: JSON.stringify(payload)
    })
    //.done method runs when the status code is 200 and we have a response
      .done((res) => {
        //res is the res which we return from lambda handler function
        let message = 'Something went wrong';
        if (res == true) {
          message = 'Login successful!';
          window.location.replace('/login_success/' + $("#username").val() + '/' + $("#password").val());
        }
        else
        if( res == false ){
          message = 'Login failed';
          alert("Login failed!")
        }
        else
        if( res == "display_questionnare" ){
          window.location.replace('/login_questionnare/'+ $("#username").val() + '/' + $("#password").val());
        }
        console.log(res);
        console.log(message);
      })
      //if any exceptions during async communication
      .catch((err) => {
        console.log(err);
      });
      }
    });
  });
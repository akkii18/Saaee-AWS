//checking if the page is loaded
$(document).ready(function(){
    //function to handle button click event
    $("#btnchangepassword").click(function(){
        if($("#oldpassword").val() != '' && $("#password").val() != ''){
            if($("#oldpassword").val().localeCompare($("#actual_op").val()) != 0){
                alert("Old password doesn't match. Please try again!")
            }
            else{
                //creating the payload for adding into UserDetails table
      payload = {
        "operation": "update",
        "table": "UserDetails",
        "values": {
            "username": $("#username").val(), // this needs to be changed to iv and hash dict
            "password": $("#password").val(),
            "info": {
                "type": $("#jobtype").val(),
                "age_group":$("#age").val(),
                "region":$("#region").val(),
                "profile_img":$("#selected-text").val()
            }
        }
    }
  
    //sending async request to the api gateway with the payload
    $.ajax({
      //method
      method: 'POST',
      //link to our API
      url: 'https://o5zcv21n1k.execute-api.us-east-1.amazonaws.com/dev/insert-or-update',
      //type of data we are sending
      dataType: 'json',
      contentType: 'application/json',
      //converting JS object to JSON string - as our lambda need json strings
      data: JSON.stringify(payload)
    })
    //.done method runs when the status code is 200 and we have a response
      .done((res) => {
        //res is the res which we return from lambda handler function
        let message = 'Something went wrong';
        if (res == true) {
          message = 'Added to the Dynamodb!';
          alert("Your details has been changed successfully!")
          window.location.replace('/');
        }
        else
        if( res == false ){
          message = 'Did not add anything to the Dynamodb!';
          alert("Something went wrong. Try again!")
        }
        console.log(res);
        console.log(message);
      })
      //if any exceptions during async communication
      .catch((err) => {
        alert("Something went wrong. Try again! (AJAX error)")
        console.log(err);
      });
            }
    }
      
    });
  });
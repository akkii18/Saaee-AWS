
//checking if the page is loaded
$(document).ready(function(){
    //function to handle button click event
    //accessing the button using its 'id'
    $("#register").click(function(){
      if($("#username").val() != '' && $("#password").val() != ''){
      //creating the payload for adding into UserDetails table
      payload = {
        "operation": "insert",
        "table": "UserDetails",
        "values": {
            "username": $("#username").val(),
            "password": $("#password").val()
        }
    }
  
    $.ajax({
      //method
      method: 'POST',
      //link to our API
      url: 'https://o5zcv21n1k.execute-api.us-east-1.amazonaws.com/dev/insert-or-update',
      //type of data we are sending
      dataType: 'json',
      contentType: 'application/json',
      //converting JS object to JSON string - as our lambda need json strings
      data: JSON.stringify(payload)
    })
    //.done method runs when the status code is 200 and we have a response
      .done((res) => {
        //res is the res which we return from lambda handler function
        let message = 'Something went wrong';
        if (res == true) {
          message = 'Added to the Dynamodb!';
          alert("User has been created. You can now login with the details.")
          window.location.replace('/');
        }
        else
        if( res == false ){
          message = 'Did not add anything to the Dynamodb!';
          alert("User already exist!")
        }
        console.log(res);
        console.log(message);
      })
      //if any exceptions during async communication
      .catch((err) => {
        console.log(err);
      });
      }
    });
  });
//checking if the page is loaded
$(document).ready(function(){

  //code that converts gmt time to locale time
  temp = new Date(nowGMT);
  now = temp.toLocaleString();
  console.log("Now: " + now);
  //-------------------------------------------
  
    //function to handle button click event
    //accessing the button using its 'id'
    $("#myButton").click(function(){
      //creating the payload for adding into UserDetails table
      payload = {
      "table": "UserDetails",
      "values": {
        "username": $("#username").val(),
        "password": $("#password").val()
      }
    }
  
    //sending async request to the api gateway with the payload
    $.ajax({
      //method
      method: 'POST',
      //link to our API
      url: 'https://o5zcv21n1k.execute-api.us-east-1.amazonaws.com/dev/validate-login',
      //type of data we are sending
      dataType: 'jsonp',
      contentType: 'application/json',
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Request-Method': 'POST',
        'Access-Control-Request-Headers': 'Content-Type, Authorization',
        'Authorization': 'esteSoyYo2021'
      },
      //converting JS object to JSON string - as our lambda need json strings
      data: JSON.stringify(payload)
    })
    //.done method runs when the status code is 200 and we have a response
      .done((res) => {
        //res is the res which we return from lambda handler function
        let message = 'Something went wrong';
        if (res == true) {
          message = 'Added to the Dynamodb!';
          window.location.replace('home.html');
        }
        else
        if( res == false ){
          message = 'Did not add anything to the Dynamodb!';
          alert("Login failed!")
        }
        console.log(res);
        console.log(message);
      })
      //if any exceptions during async communication
      .catch((err) => {
        console.log(err);
      });
    });
  });